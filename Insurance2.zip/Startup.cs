﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CashRecieptForInsuranceVersion2.Startup))]
namespace CashRecieptForInsuranceVersion2
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CashRecieptForInsuranceVersion2.Models
{
    public class box
    {
        public string Name { get; set; }
        public int ID { get; set; }
    }
}
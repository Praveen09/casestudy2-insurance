﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CashRecieptForInsuranceVersion2.Models
{
    public class Login
    {
        [Required(ErrorMessage = "Required")]
        public string vUserName { get; set; }
        [Required(ErrorMessage = "Required")]
        [DataType(DataType.Password)]
        public string vPassword { get; set; }
       
       
    }
}
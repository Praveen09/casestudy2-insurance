﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CashRecieptForInsuranceVersion2.Models
{
    public class Calc
    {
        [Required(ErrorMessage = "Required")]
        public string PolicyType1 { get; set; }
        [Required(ErrorMessage = "Required")]
        public double interest1 { get; set; }
        [Required(ErrorMessage = "Required")]
        public string TypeOfInstallment1 { get; set; }
        [Required(ErrorMessage = "Required")]
        public double InsAmount1 { get; set; }
    }
}
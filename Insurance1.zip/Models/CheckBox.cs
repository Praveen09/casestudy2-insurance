﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CashRecieptForInsuranceVersion2.Models
{
    public class CheckBox
    {
        public string  mode { get; set; }
    }
}
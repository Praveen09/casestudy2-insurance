﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CashRecieptForInsuranceVersion2.Models
{
    public class PolicySelect
    {
        [Required(ErrorMessage = "Required")]
        public string PolicyType { get; set; }
          [Required(ErrorMessage = "Required")]
        public int InsYear { get; set; }

        [Required(ErrorMessage="Required")]
          public double InsAmount { get; set; }

         [Required(ErrorMessage = "Required")]
        public string TypeOfInstallment { get; set; }

         [Required(ErrorMessage = "Required")]
         public double Premium { get; set; }

        [Required(ErrorMessage = "Required")]
         public string vModeOfPayment { get; set; }

        

       
    }
    
}
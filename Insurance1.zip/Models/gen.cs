﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CashRecieptForInsuranceVersion2.Models
{
    public class gen
    {
        public int custId { get; set; }
        public int polId { get; set; }
    }
}
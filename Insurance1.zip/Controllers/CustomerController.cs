﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CashRecieptForInsuranceVersion2.Models;
using System.Windows.Forms;

namespace CashRecieptForInsuranceVersion2.Controllers
{
    public class CustomerController : Controller
    {
        private CashRecieptForInsuranceEntities2 db = new CashRecieptForInsuranceEntities2();
        public CustomerController()
        {
            db = new CashRecieptForInsuranceEntities2();
        }
        [HttpPost]
        public JsonResult AjaxMethod(string name)
        {
            string person = name;

            MessageBox.Show(person);
            return Json(person);
        }
        public ActionResult About()
        {
            if(Session["Id"]!=null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }

        }
        public ActionResult Contact()
        {
            if (Session["Id"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        // GET: Customer
        public ActionResult Index()
        {
            if (Session["Id"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                int id = (int)Session["id"];
                tblCustomerList ch= db.tblCustomerLists.Find(id);
                tblPolicyApplicationList danger = db.tblPolicyApplicationLists.Where(a=>a.dNextDueDate<=DateTime.Now&&a.bPaymentStatus==false&& a.iCustomerId==id).FirstOrDefault();
                if (ch != null)
                {
                    if (danger != null)
                    {
                        Session["danger"] = "one or more of your policy payment is not yet done!!you are in red List!!";
                        return View();
                    }
                    else
                    {
                        Session["danger"] = "";
                        return View();
                    }
                    }
                else
                {
                    return RedirectToAction("Index", "Home");
                }






               
            return View();
            }
        }

        public ActionResult ChangePassword()
        {
            if (Session["Id"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        [HttpPost]
        public ActionResult ChangePassword(ChPassword ch)
        {
            if (Session["id"] != null)
            {
                if (ch.NewPassword == ch.ConfirmPassword)
                {
                    var user = Session["Name"].ToString();
                    var pas = ch.OldPassword;
                    try
                    {

                        CashRecieptForInsuranceEntities2 obj = new CashRecieptForInsuranceEntities2();
                        tblCustomerList obj1 = (from e in obj.tblCustomerLists
                                    where e.vUserName == user && e.vPassword == pas
                                    select e).FirstOrDefault();
                        if (obj1.vPassword==pas)
                        {
                            obj1.vPassword = ch.NewPassword;
                            obj.SaveChanges();
                            return RedirectToAction("Index");
                        }
                        else
                        {
                            ModelState.AddModelError("Error", "Wrong old Password Provided!!");
                            return View();
                        }

                    }
                    catch
                    {
                        
                        return View();
                        
                    }
                }
                else
                {
                    ModelState.AddModelError("Error", "New Password and confirm Password do not match!!");
                    return View();

                }
            }
            else
                return RedirectToAction("Index", "Home");


        }
       
        
        [HttpGet]
        public ActionResult Generate(int cusid, int policyid)
        {
            //tblPolicyApplicationList qw = db.tblPolicyApplicationLists.Where(a => a.iPolicyNumber == policyid && a.iCustomerId == cusid).FirstOrDefault();
            //qw.vStatus = "Generated";
            //db.SaveChanges();

            if (Session["Id"] != null)
            {
                var fullname = new gen();
                fullname.custId = cusid;
                fullname.polId = policyid;
                return new Rotativa.ActionAsPdf("gen", fullname) { FileName = "CashReciept.pdf" };
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
           


        }
        [HttpGet]
        public ActionResult gen(gen ID)
        {
            
                int cusid1 = ID.custId;
                int policyid1 = ID.polId;



                tblPolicyApplicationList qw = db.tblPolicyApplicationLists.Where(a => a.iPolicyNumber == policyid1 && a.iCustomerId == cusid1).FirstOrDefault();
                tblPolicyApplicationGeneratedList pp = db.tblPolicyApplicationGeneratedLists.Where(a => a.iPolicyNumber == policyid1 && a.iCustomerId == cusid1).FirstOrDefault();

                if (pp != null)
                {
                    var v = db.tblCustomerLists.Find(qw.iCustomerId).vFirstName;
                    var w = db.tblCustomerLists.Find(qw.iCustomerId).vLastName;
                    pp.vStatus = v + " " + w;
                    qw.vStatus = "pending";
                    db.SaveChanges();
                    return View(pp);

                }
                else
                {
                    return View("Error");
                }
            }
            
             
            
        
        // GET: Customer/Details/5
        public ActionResult Details()
        {
            if (Session["Id"] != null)
            {
              
            var id = Session["id"];
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblCustomerList tblCustomerList = db.tblCustomerLists.Find(id);
            if (tblCustomerList == null)
            {
                return HttpNotFound();
            }
            return View(tblCustomerList);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        public ActionResult ApplyPolicy()
        {
            if (Session["Id"] != null)
            {
                
            List<SelectListItem> Country = new List<SelectListItem>();
            Country.Add(new SelectListItem { Text = "--Select--", Selected = true, Disabled = true });
            foreach (var item in db.tblPolicies)
            {
                Country.Add(new SelectListItem { Text = item.vPolicyName, Value = item.vPolicyName });
            }

            ViewBag.PolicyType = Country;
            
            return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }


        }
        [HttpPost]
        public ActionResult ApplyPolicy( PolicySelect ps)
        {
            DateTime ty = DateTime.Now;
            if(ps==null)
            {
                return HttpNotFound();
            }
            else
            { 
                
                if ((ps.PolicyType != null) && (ps.InsYear != null) && (ps.InsAmount != null) && (ps.TypeOfInstallment != null))
        {   var z=0;
        var x = ps.InsYear;
        var y = ps.InsAmount;
        if (ps.TypeOfInstallment == "Monthly")
            {
                 z = 12;
            }
        else if (ps.TypeOfInstallment == "Quarterly") 
            {
                z = 4;
            }
        else if (ps.TypeOfInstallment == "Half")
            {
                 z = 2;
            }
        else if (ps.TypeOfInstallment == "Annually")
            {
                 z = 1;
            }

        try
        {
            tblPolicy po = db.tblPolicies.Where(a => a.vPolicyName == ps.PolicyType).FirstOrDefault();
            var interest = po.iInterest;

            var premium = (y*interest) / ( z * x);
            ps.Premium = premium;
            MessageBox.Show("Estimated Premium Amount is Rs. " +ps.Premium.ToString());
        }
        catch (Exception)
        {
            
            throw;
        }
        int m = (12 / z);

            tblPolicyApplicationList appl = new tblPolicyApplicationList();
            tblPolicy pol = new tblPolicy();
            //tblPolicy qw1 = (from u in db.tblPolicies where u.vPolicyName.Equals(ps.PolicyType) select u).FirstOrDefault();
            var qw1 = db.tblPolicies.Where(a => a.vPolicyName==ps.PolicyType).FirstOrDefault();
            appl.iPolicyNumber = qw1.iPolicyNumber;
            appl.iCustomerId = (int)Session["Id"];
            appl.iAmount = (long)ps.InsAmount;
            appl.iYears = ps.InsYear;
            appl.vTypeOfInstallment = ps.TypeOfInstallment;
            appl.iPremium = (decimal)ps.Premium;
            appl.dNextDueDate = ty.AddMonths(m);
            appl.dStartDate = ty;
            appl.dEndDate = ty.AddYears(x);
            appl.vStatus = "pending";
            appl.bPaymentStatus = false;
            appl.vModeOfPayment = ps.vModeOfPayment;
                   

            try
            {
                db.tblPolicyApplicationLists.Add(appl);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                ModelState.AddModelError("Error", "Already applied!!");
                return View();
            }
                

            return View();
        }

            }
            return View();

        }
        public ActionResult PremiumCalculator()
        {
            if (Session["Id"] != null)
            {
              
            return PartialView();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        [HttpPost]
        public ActionResult PremiumCalculator(Calc pre)
        {
            if (pre == null)
            {
                return HttpNotFound();
            }
            else
            {
                if ((pre.PolicyType1 != null) && (pre.InsAmount1 != null) && (pre.TypeOfInstallment1 != null))
                {
                    var z = 0;

                    var y = pre.InsAmount1;
                    if (pre.TypeOfInstallment1 == "Monthly")
                    {
                        z = 12;
                    }
                    else if (pre.TypeOfInstallment1 == "Quarterly")
                    {
                        z = 4;
                    }
                    else if (pre.TypeOfInstallment1 == "Half")
                    {
                        z = 2;
                    }
                    else if (pre.TypeOfInstallment1 == "Annually")
                    {
                        z = 1;
                    }
                    tblPolicy po = db.tblPolicies.Where(a => a.vPolicyName == pre.PolicyType1).FirstOrDefault();
                    var interest = po.iInterest;

                    var premium1= (y) / (10 * z*interest);

                    //pre.Premium = premium;
                    MessageBox.Show(premium1.ToString());
                    return PartialView();
                }

            }
            return PartialView();
        }
        [HttpGet]
        public ActionResult AppliedPolicyList()
        {
            if (Session["Id"] != null)
            {
                
            int id = (int)Session["Id"];
            var app = db.tblPolicyApplicationLists.Where(a => a.iCustomerId == id);
            return View(app);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        [HttpGet]
        public ActionResult PayList()
        {
            if (Session["Id"] != null)
            {
                
            int id = (int)Session["Id"];
            var app = db.tblPolicyApplicationLists.Where(a => a.iCustomerId == id);
            return View(app);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        [HttpGet]
        public ActionResult Paid()
        {
            if (Session["Id"] != null)
            {
               
            int id2 = (int)Session["blur"];
            int id1 = (int)Session["Id"];
            var app = db.tblPolicyApplicationLists.Where(a => a.iCustomerId == id1&&a.iPolicyNumber==id2).FirstOrDefault();
            return View(app);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        [HttpGet]
        public ActionResult PayNow(int id)
        {
            if (Session["Id"] != null)
            {
                
            int id1 = (int)Session["Id"];
            var pp = db.tblPolicyApplicationGeneratedLists.Where(a => a.iCustomerId == id1 && a.iPolicyNumber == id).FirstOrDefault();
            var app = db.tblPolicyApplicationLists.Where(a => a.iCustomerId == id1&&a.iPolicyNumber==id).FirstOrDefault();
            if (pp != null)
            {
                db.tblPolicyApplicationGeneratedLists.Remove(pp);
                db.SaveChanges();
            }
            Session["blur"] = app.iPolicyNumber;
            if(app!=null)
            {
                app.bPaymentStatus = true;
                db.SaveChanges();
                return RedirectToAction("Paid");
            }

            return View("Error");

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }

        }
        // GET: Customer/Create
        public ActionResult Create()
        {
            if (Session["Id"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }


        // POST: Customer/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "iCustomerId,vFirstName,vLastName,vUserName,vPassword,iAge,vDOB,vGender,vOccupation,vMartialStatus,vEmailId,iContactNumber,vPanId")] tblCustomerList tblCustomerList)
        {
            if (Session["Id"] != null)
            {
                
            if (ModelState.IsValid)
            {
                db.tblCustomerLists.Add(tblCustomerList);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(tblCustomerList);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }

        }
        /// <summary>
        /// /////////////////////////////////////////////////////////////
         // GET: Clerk/Create
        public ActionResult CreateC()
        {
            if (Session["Id"] != null)
            {

                return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // POST: Clerk/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateC([Bind(Include = "iClerkId,vFirstName,vLastName,vUserName,vPassword,vEmailId,iContactNumber,vPanId")] tblClerkList tblClerkList)
        {
            if (Session["Id"] != null)
            {

                if (ModelState.IsValid)
                {
                    db.tblClerkLists.Add(tblClerkList);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                return View(tblClerkList);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        /// </summary>
        /// <returns></returns>
        // GET: Customer/Edit/5
        public ActionResult Edit()
        {
            if (Session["Id"] != null)
            {
                
            var id = Session["id"];
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblCustomerList tblCustomerList = db.tblCustomerLists.Find(id);
            if (tblCustomerList == null)
            {
                return HttpNotFound();
            }
            return View(tblCustomerList);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // POST: Customer/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "iCustomerId,vFirstName,vLastName,vUserName,vPassword,iAge,vDOB,vGender,vOccupation,vMartialStatus,vEmailId,iContactNumber,vPanId")] tblCustomerList tblCustomerList)
        {
            if (Session["Id"] != null)
            {
              
            if (ModelState.IsValid)
            {
                db.Entry(tblCustomerList).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tblCustomerList);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // GET: Customer/Delete/5
        public ActionResult Delete(tblPolicy id)
        {
            if (Session["Id"] != null)
            {

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblCustomerList tblCustomerList = db.tblCustomerLists.Find(id);
            if (tblCustomerList == null)
            {
                return HttpNotFound();
            }
            return View(tblCustomerList);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // POST: Customer/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (Session["Id"] != null)
            {
            tblCustomerList tblCustomerList = db.tblCustomerLists.Find(id);
            db.tblCustomerLists.Remove(tblCustomerList);
            db.SaveChanges();
            return RedirectToAction("Index");

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        protected override void Dispose(bool disposing)
        {
            
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
            }
            
        }

        //public ActionResult Message()
        //{
        //    box box = new box
        //    {
        //        Name = "Adrash Sajeev",
        //        ID = 1            
        //    };
        //    ViewData["MYBox"] = box;
        //    return View();
        //}
    }


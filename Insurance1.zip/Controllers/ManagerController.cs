﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CashRecieptForInsuranceVersion2.Models;

namespace CashRecieptForInsuranceVersion2.Controllers
{
    public class ManagerController : Controller
    {
        private CashRecieptForInsuranceEntities2 db = new CashRecieptForInsuranceEntities2();

        // GET: Manager
        public ActionResult Index()
        {
            if (Session["Id"] != null)
            {

            return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
            
        }
        public ActionResult About()
        {
            if (Session["Id"] != null)
            {

            return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        public ActionResult Contact()
        {
            if (Session["Id"] != null)
            {

            return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        public ActionResult ChangePassword()
        {
            if (Session["Id"] != null)
            {
            return View();

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        [HttpPost]
        public ActionResult ChangePassword(ChPassword ch)
        {
            if (Session["Id"] != null)
            {
                if (Session["id"] != null)
                {
                    if (ch.NewPassword == ch.ConfirmPassword)
                    {
                        var user = Session["Name"].ToString();
                        var pas = ch.OldPassword;
                        try
                        {

                            CashRecieptForInsuranceEntities2 obj = new CashRecieptForInsuranceEntities2();
                            tblAuthorityList obj1 = (from e in obj.tblAuthorityLists
                                                     where e.vUserName == user && e.vPassword == pas
                                                     select e).FirstOrDefault();
                            if (obj1.vPassword == pas)
                            {
                                obj1.vPassword = ch.NewPassword;
                                obj.SaveChanges();
                                return RedirectToAction("Index");
                            }
                            else
                            {
                                ModelState.AddModelError("Error", "Wrong old Password Provided!!");
                                return View();
                            }

                        }
                        catch
                        {

                            return View();

                        }
                    }
                    else
                    {
                        ModelState.AddModelError("Error", "New Password and confirm Password do not match!!");
                        return View();

                    }
                }
                else
                    return RedirectToAction("Index", "Home");

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
           

        }
       
        [HttpGet]
        public ActionResult PolicyHoldersList()
        {
            if (Session["Id"] != null)
            {
                
            return View(db.tblPolicyApplicationLists.ToList());

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        // GET: Manager/Details/5
        public ActionResult Details()
        {
            if (Session["Id"] != null)
            {


            var id = Session["id"];
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblAuthorityList tblAuthorityList = db.tblAuthorityLists.Find(id);
            if (tblAuthorityList == null)
            {
                return HttpNotFound();
            }
            return View(tblAuthorityList);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        [HttpPost]
       
        public ActionResult PolicyHoldersList(tblPolicyApplicationList pl)
        {

            return RedirectToAction("PolicyHolderDetails", new { cusid = pl.iCustomerId, policyid = pl.iPolicyNumber });
        }
        [HttpGet]
        public ActionResult RedList()
        {
            if (Session["Id"] != null)
            {

            var list = db.tblPolicyApplicationLists.Where(a => a.dNextDueDate < DateTime.Now);
            if (list!=null)
            {
                return View(list); 
            }
            else
            {
                 return RedirectToAction("Index");
            }

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
       
      [HttpGet]
        public ActionResult DeleteRed(int cusid,int policyid)
        {
            if (Session["Id"] != null)
            {

            if (cusid==null||policyid==null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblPolicyApplicationList qw = db.tblPolicyApplicationLists.Where(a => a.iPolicyNumber == policyid && a.iCustomerId == cusid ).FirstOrDefault();
            if (qw == null)
            {
                return HttpNotFound();
            }
            return View(qw);

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
   
        
      public ActionResult DeleteRed1(int cusid1, int policyid1)
      {
          if (Session["Id"] != null)
          {


          tblPolicyApplicationList qw = db.tblPolicyApplicationLists.Where(a => a.iPolicyNumber == policyid1 && a.iCustomerId == cusid1).FirstOrDefault();
          if (qw == null)
          {
              return HttpNotFound();
          }
          else
          {
              db.tblPolicyApplicationLists.Remove(qw);
              db.SaveChanges();
              return RedirectToAction("RedList");
          }
          }
          else
          {
              return RedirectToAction("Index", "Home");
          }
      }
        [HttpGet]
      public ActionResult PolicyList()
      {
          if (Session["Id"] != null)
          {


          return View(db.tblPolicies.ToList());
          }
          else
          {
              return RedirectToAction("Index", "Home");
          }
      }

        [HttpGet]
      public ActionResult AddPolicy()
        {
            if (Session["Id"] != null)
            {


          return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
      }
        [HttpPost]
        public ActionResult AddPolicy(tblPolicy pol)
        {

            try
            {
               
                db.tblPolicies.Add(pol);
                db.SaveChanges();
                return RedirectToAction("index");

            }
            catch (Exception)
            {

                return RedirectToAction("Error", "Shared");
            }
        }
        [HttpGet]
        public ActionResult SearchPolicy()
        {
            if (Session["Id"] != null)
            {


            return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        [HttpPost]
        public ActionResult SearchPolicy(tblPolicy pol)
        {
            if (Session["Id"] != null)
            {

            tblPolicy pp = db.tblPolicies.Find(pol.iPolicyNumber);

            return View(pp);

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        [HttpGet]
        public ActionResult RemovePolicy(int id)
        {
            if (Session["Id"] != null)
            {

            tblPolicy pol = db.tblPolicies.Find(id);
            try
            {
                db.tblPolicies.Remove(pol);
                db.SaveChanges();
                

            }
            catch (Exception)
            {
                
                return View();
            }

            return RedirectToAction("Index");

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // GET: Manager/Create
        public ActionResult Create()
        {
            if (Session["Id"] != null)
            {


            return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // POST: Manager/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "iAuthorityId,vUserName,vPassword,vEmailId")] tblAuthorityList tblAuthorityList)
        {
            if (Session["Id"] != null)
            {


            if (ModelState.IsValid)
            {
                db.tblAuthorityLists.Add(tblAuthorityList);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(tblAuthorityList);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // GET: Manager/Edit/5
        public ActionResult Edit(int? id)
        {
            if (Session["Id"] != null)
            {


            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblAuthorityList tblAuthorityList = db.tblAuthorityLists.Find(id);
            if (tblAuthorityList == null)
            {
                return HttpNotFound();
            }
            return View(tblAuthorityList);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // POST: Manager/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "iAuthorityId,vUserName,vPassword,vEmailId")] tblAuthorityList tblAuthorityList)
        {
            if (Session["Id"] != null)
            {

            if (ModelState.IsValid)
            {
                db.Entry(tblAuthorityList).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tblAuthorityList);

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // GET: Manager/Delete/5

        // POST: Manager/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (Session["Id"] != null)
            {

            tblAuthorityList tblAuthorityList = db.tblAuthorityLists.Find(id);
            db.tblAuthorityLists.Remove(tblAuthorityList);
            db.SaveChanges();
            return RedirectToAction("Index");

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (Session["Id"] != null)
            {


            
                db.Dispose();
            }
            base.Dispose(disposing);
            }

        [HttpGet]
        public ActionResult SignUpC()
        {
            return View();
        }
        [HttpPost]
        public ActionResult SignUpC(tblClerkList cus)
        {
            try
            {
                tblLoginStatu addclient = new tblLoginStatu();
                addclient.iLockCount = 0;
                addclient.iId = 2;
                addclient.dLockedTime = DateTime.Now;
                addclient.vUserName = cus.vUserName;
                db.tblLoginStatus.Add(addclient);
                db.tblClerkLists.Add(cus);
                db.SaveChanges();
                return RedirectToAction("index");

            }
            catch (Exception)
            {

                return RedirectToAction("Error", "Shared");
            }
        }
        public ActionResult CreateC()
        {
            if (Session["Id"] != null)
            {

                return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // POST: Clerk/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateC([Bind(Include = "iClerkId,vFirstName,vLastName,vUserName,vPassword,vEmailId,iContactNumber,vPanId")] tblClerkList tblClerkList)
        {
            if (Session["Id"] != null)
            {

                if (ModelState.IsValid)
                {
                    db.tblClerkLists.Add(tblClerkList);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                return View(tblClerkList);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
    }
}


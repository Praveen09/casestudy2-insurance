﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;
using CashRecieptForInsuranceVersion2.Models;

namespace CashRecieptForInsuranceVersion2.Controllers
{
    public class ClerkController : Controller
    {
        private CashRecieptForInsuranceEntities2 db = new CashRecieptForInsuranceEntities2();

        // GET: Clerk
        public ActionResult Index()
        {
            if (Session["Id"] != null)
            {

            return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        public ActionResult About()
        {
            if (Session["Id"] != null)
            {

            return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        public ActionResult Contact()
        {
            if (Session["Id"] != null)
            {

            return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        public ActionResult ChangePassword()
        {
            if (Session["Id"] != null)
            {

            return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        [HttpPost]
        public ActionResult ChangePassword(ChPassword ch)
        {
            if (Session["id"] != null)
            {
                if (ch.NewPassword == ch.ConfirmPassword)
                {
                    var user = Session["Name"].ToString();
                    var pas = ch.OldPassword;
                    try
                    {
                        CashRecieptForInsuranceEntities2 obj = new CashRecieptForInsuranceEntities2();
                        tblClerkList obj1 = (from e in obj.tblClerkLists
                                                where e.vUserName == user && e.vPassword == pas
                                                select e).FirstOrDefault();
                        if (obj1.vPassword == pas)
                        {
                            obj1.vPassword = ch.NewPassword;
                            obj.SaveChanges();
                            return RedirectToAction("Index");
                        }
                        else
                        {
                            ModelState.AddModelError("Error", "Wrong old Password Provided!!");
                            return View();
                        }

                    }
                    catch
                    {

                        return View();

                    }
                }
                else
                {
                    ModelState.AddModelError("Error", "New Password and confirm Password do not match!!");
                    return View();

                }
            }
            else
                return RedirectToAction("Index", "Home");


        }
       
        public ActionResult PolicyHoldersList()
        {
            if (Session["Id"] != null)
            {

            return View(db.tblPolicyApplicationLists.ToList());
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        [HttpPost]
          public ActionResult PolicyHoldersList(tblPolicyApplicationList pl)
        {
            if (Session["Id"] != null)
            {

            Session["kk"] = pl.iPolicyNumber;

            return RedirectToAction("PolicyHolderDetails", new { cusid = pl.iCustomerId, policyid = pl.iPolicyNumber });
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        [HttpGet]
   public ActionResult CashReciept(int cusid,int policyid)
        {
            if (Session["Id"] != null)
            {

            tblPolicyApplicationList qw = db.tblPolicyApplicationLists.Where(a => a.iPolicyNumber == policyid && a.iCustomerId == cusid).FirstOrDefault();
          return View(qw);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
    


        //[HttpGet]
        //public ActionResult Generate(int cusid,int policyid)
        //{
        //  tblPolicyApplicationList qw = db.tblPolicyApplicationLists.Where(a=>a.iPolicyNumber==policyid&& a.iCustomerId == cusid).FirstOrDefault();
        //  qw.vStatus = "Generated";
        //  db.SaveChanges();

        //    var fullname = new gen();
        //    fullname.custId = cusid;
        //    fullname.polId = policyid;
        //    return new Rotativa.ActionAsPdf("gen", fullname) { FileName = "CashReciept.pdf" };

            
        //}
        [HttpGet]
        public ActionResult generated(int policyid,int cusid)
        {
            if (Session["Id"] != null)
            {

                tblPolicyApplicationList qw = db.tblPolicyApplicationLists.Where(a => a.iPolicyNumber == policyid && a.iCustomerId == cusid).FirstOrDefault();
            if (qw.vStatus =="Generated")
            {
                tblPolicyApplicationGeneratedList qq = db.tblPolicyApplicationGeneratedLists.Where(a => a.iPolicyNumber == policyid && a.iCustomerId == cusid).FirstOrDefault();
                if (qq != null)
                {
                    db.tblPolicyApplicationGeneratedLists.Remove(qq);
                    db.SaveChanges();
                }

                return View("Already");
            }
            else
            {
               
               tblPolicyApplicationGeneratedList pp = new tblPolicyApplicationGeneratedList();
                pp.iPolicyNumber = qw.iPolicyNumber;
                pp.iCustomerId = qw.iCustomerId;
                pp.bPaymentStatus = qw.bPaymentStatus;
                pp.dEndDate = qw.dEndDate;

                pp.dStartDate = qw.dStartDate;
                pp.iAmount = qw.iAmount;
                pp.iPremium = qw.iPremium;
                pp.iYears = qw.iYears;
                pp.vModeOfPayment = qw.vModeOfPayment;
                pp.vTypeOfInstallment = qw.vTypeOfInstallment;

                string typeOfinst = qw.vTypeOfInstallment;
                if (typeOfinst == "Monthly")
                {
                    pp.dNextDueDate = qw.dNextDueDate.AddMonths(-1);
                }
                else if (typeOfinst == "Quarterly")
                {
                    pp.dNextDueDate = qw.dNextDueDate.AddMonths(-3);
                }
                else if (typeOfinst == "Half")
                {
                    pp.dNextDueDate = qw.dNextDueDate.AddMonths(-6);
                }
                else if (typeOfinst == "Annually")
                {
                    pp.dNextDueDate = qw.dNextDueDate.AddMonths(-12);
                }
                var v = db.tblCustomerLists.Find(qw.iCustomerId).vFirstName;
                var w = db.tblCustomerLists.Find(qw.iCustomerId).vLastName;
                pp.vStatus = v + " " + w;
                pp.dGenDate= DateTime.Now;
                db.tblPolicyApplicationGeneratedLists.Add(pp);

                qw.vStatus = "Generated";
                db.SaveChanges();
                return View();
            }
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }


        // GET: Clerk/Details/5
        public ActionResult Details()
        {
            if (Session["Id"] != null)
            {

            var id = Session["id"];
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblClerkList tblClerkList = db.tblClerkLists.Find(id);
            if (tblClerkList == null)
            {
                return HttpNotFound();
            }
            return View(tblClerkList);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }


        [HttpPost]
        public JsonResult AjaxMethod(string name)
        {
            
            string person = name;

            MessageBox.Show(person);
            return Json(person);
            
        }

        [HttpGet]
        public ActionResult PolicyHolderDetails(int cusid,int policyid )
        {
            if (Session["Id"] != null)
            {

            
                Session["Idk"] = cusid;
            Session["kk"] = policyid;
            tblPolicyApplicationList qw1 = db.tblPolicyApplicationLists.Where(a=>a.iPolicyNumber==policyid&& a.iCustomerId == cusid).FirstOrDefault();

            return View(qw1);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
           
            
          

        }
        

        [HttpGet]
        public ActionResult PolicyHolderDetails1(int cusid,int policyid)
        {
            if (Session["Id"] != null)
            {

            Session["Idk"] = cusid;
            Session["kk1"] = policyid ;
           
            tblPolicyApplicationList qw = db.tblPolicyApplicationLists.Where(a => a.iPolicyNumber == policyid && a.iCustomerId == cusid).FirstOrDefault();
          
             string typeOfinst = qw.vTypeOfInstallment;
            if (qw.vStatus !="Generated")
            {
                if (typeOfinst == "Monthly")
                {
                    qw.dNextDueDate = qw.dNextDueDate.AddMonths(1);
                }
                else if (typeOfinst == "Quarterly")
                {
                    qw.dNextDueDate = qw.dNextDueDate.AddMonths(3);
                }
                else if (typeOfinst == "Half")
                {
                    qw.dNextDueDate = qw.dNextDueDate.AddMonths(6);
                }
                else if (typeOfinst == "Annually")
                {
                    qw.dNextDueDate = qw.dNextDueDate.AddMonths(12);
                }
               
                qw.bPaymentStatus = false;
                db.SaveChanges();
                return View(qw); 
            }
            else
            {
                return View("Already");
            }

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }


        }
        [HttpGet]
        public ActionResult d()
        {
            if (Session["Id"] != null)
            {

            return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
        // GET: Clerk/Create
        public ActionResult Create()
        {
            if (Session["Id"] != null)
            {

            return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // POST: Clerk/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "iClerkId,vFirstName,vLastName,vUserName,vPassword,vEmailId,iContactNumber,vPanId")] tblClerkList tblClerkList)
        {
            if (Session["Id"] != null)
            {

            if (ModelState.IsValid)
            {
                db.tblClerkLists.Add(tblClerkList);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(tblClerkList);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // GET: Clerk/Edit/5
        public ActionResult Edit()
        {
            if (Session["Id"] != null)
            {

            var id = Session["id"];
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblClerkList tblClerkList = db.tblClerkLists.Find(id);
            if (tblClerkList == null)
            {
                return HttpNotFound();
            }
            return View(tblClerkList);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // POST: Clerk/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "iClerkId,vFirstName,vLastName,vUserName,vPassword,vEmailId,iContactNumber,vPanId")] tblClerkList tblClerkList)
        {
            if (Session["Id"] != null)
            {

            if (ModelState.IsValid)
            {
                db.Entry(tblClerkList).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tblClerkList);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // GET: Clerk/Delete/5
        public ActionResult Delete(int? id)
        {
            if (Session["Id"] != null)
            {

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblClerkList tblClerkList = db.tblClerkLists.Find(id);
            if (tblClerkList == null)
            {
                return HttpNotFound();
            }
            return View(tblClerkList);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // POST: Clerk/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (Session["Id"] != null)
            {
            tblClerkList tblClerkList = db.tblClerkLists.Find(id);
            db.tblClerkLists.Remove(tblClerkList);
            db.SaveChanges();
            return RedirectToAction("Index");

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        protected override void Dispose(bool disposing)
        {
            

            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
            }

        [HttpGet]
        public ActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public ActionResult SignUp(tblCustomerList cus)
        {
            try
            {
                tblLoginStatu addclient = new tblLoginStatu();
                addclient.iLockCount = 0;
                addclient.iId = 1;
                addclient.dLockedTime = DateTime.Now;
                addclient.vUserName = cus.vUserName;
                db.tblLoginStatus.Add(addclient);
                db.tblCustomerLists.Add(cus);
                db.SaveChanges();
                return RedirectToAction("index");

            }
            catch (Exception)
            {

                return RedirectToAction("Error", "Shared");
            }
        }
        // GET: Customer/Create
        public ActionResult CreateCustomer()
        {
            if (Session["Id"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }


        // POST: Customer/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateCustomer([Bind(Include = "iCustomerId,vFirstName,vLastName,vUserName,vPassword,iAge,vDOB,vGender,vOccupation,vMartialStatus,vEmailId,iContactNumber,vPanId")] tblCustomerList tblCustomerList)
        {
            if (Session["Id"] != null)
            {

                if (ModelState.IsValid)
                {
                    db.tblCustomerLists.Add(tblCustomerList);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                return View(tblCustomerList);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }

        }
    }
}


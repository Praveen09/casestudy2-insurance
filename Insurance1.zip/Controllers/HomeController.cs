﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CashRecieptForInsuranceVersion2.Models;
using System.Windows.Forms;

namespace CashRecieptForInsuranceVersion2.Controllers
{
    public class HomeController : Controller
    {
        public CashRecieptForInsuranceEntities2 obj;
        public HomeController()
        {
            obj = new CashRecieptForInsuranceEntities2();
        }
        public ActionResult Index()
        {

        
            Session.Clear();
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult Products()
        {
            ViewBag.Message = "Your Product page.";

            return View();
        }
        public ActionResult forgotCus()
        {
            return View();
        }
        [HttpPost]
        public ActionResult forgotCus(forgotPassword fu)
        {
            var cus = obj.tblCustomerLists.Where(a => a.vUserName == fu.UserName && a.vEmailId == fu.EmailId).FirstOrDefault();
            if (cus!=null)
            {
                Session["Id"] = cus.iCustomerId;
                Session["Name"] = cus.vUserName;
                Session["Key"] = cus.vUserName;
                return RedirectToAction("ChangePassword", "Customer"); 
            }
            else
            {
                ModelState.AddModelError("Error", "Email Id is not matching with the username.Try Again!!");
                return View();
            }
        }

        public ActionResult forgotCle()
        {
            return View();
        }
        [HttpPost]
        public ActionResult forgotCle(forgotPassword fu)
        {
            var cus = obj.tblClerkLists.Where(a => a.vUserName == fu.UserName && a.vEmailId == fu.EmailId).FirstOrDefault();
            if (cus != null)
            {
                Session["Id"] = cus.iClerkId;
                Session["Name"] = cus.vUserName;
                Session["Key"] = cus.vUserName;
                return RedirectToAction("ChangePassword", "Clerk");
            }
            else
            {
                ModelState.AddModelError("Error", "Email Id is not matching with the username.Try Again!!");
                return View();
            }
        }

        public ActionResult forgotMan()
        {
            return View();
        }
        [HttpPost]
        public ActionResult forgotMan(forgotPassword fu)
        {
            var cus = obj.tblAuthorityLists.Where(a => a.vUserName == fu.UserName && a.vEmailId == fu.EmailId).FirstOrDefault();
            if (cus != null)
            {
                Session["Id"] = cus.iAuthorityId;
                Session["Name"] = cus.vUserName;
                Session["Key"] = cus.vUserName;
                return RedirectToAction("ChangePassword", "Manager");
            }
            else
            {
                ModelState.AddModelError("Error", "Email Id is not matching with the username.Try Again!!");
                return View();
            }
        }

        

        [HttpGet]
        public ActionResult SignUpM()
        {
            return View();
        }
        [HttpPost]
        public ActionResult SignUpM(tblAuthorityList cus)
        {
            try
            {
                tblLoginStatu addclient = new tblLoginStatu();
                addclient.iLockCount = 0;
                addclient.iId = 3;
                addclient.dLockedTime = DateTime.Now;
                addclient.vUserName = cus.vUserName;
                obj.tblLoginStatus.Add(addclient);
                obj.tblAuthorityLists.Add(cus);
                obj.SaveChanges();
                return RedirectToAction("index");

            }
            catch (Exception)
            {

                return RedirectToAction("Error", "Shared");
            }
        }

        public ActionResult LoginManager()
        {

            return View();
        }
        [HttpPost]
        [ValidateInput(true)]
        public ActionResult LoginManager(Login credentails)
        {
            string username = credentails.vUserName;
            string Password = credentails.vPassword;

            tblLoginStatu ls = (from u in obj.tblLoginStatus where u.vUserName.Equals(username) && u.iId.Equals(3) select u).FirstOrDefault();

            if (ls != null)
            {


            label1: if (ls.dLockedTime <= DateTime.Now)
                {
                    int count = ls.iLockCount;

                    if (ls.iLockCount < 3)
                    {

                        tblAuthorityList user = (from u in obj.tblAuthorityLists
                                                where u.vUserName.Equals(username) && u.vPassword.Equals(Password)
                                                select u).FirstOrDefault();

                        if (user != null)
                        {
                            Session["Id"] = user.iAuthorityId;
                            Session["Name"] = user.vUserName;
                            Session["Key"] = user.vUserName;

                            return RedirectToAction("Index", "Manager");
                        }
                        else
                        {
                            ls.iLockCount++;
                            int c = 4 - ls.iLockCount;
                            obj.SaveChanges();
                            ModelState.AddModelError("Error", "Wrong Password" + c + "more attempt left !!");
                            return View();
                        }
                    }
                    else
                    {

                        ls.dLockedTime = DateTime.Now.AddMinutes(2);

                        obj.SaveChanges();
                        goto label1;
                    }
                }
                else
                {
                    ls.iLockCount = 0;
                    obj.SaveChanges();
                    MessageBox.Show("Maximum attempt reached try after 3 minutes!!");
                    return RedirectToAction("wait");
                }

            }
            else
            {
                ModelState.AddModelError("Error", "UserId and password do not match!!");
                return View();
            }
            return View();
        }


        [HttpGet]
        public ActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public ActionResult SignUp(tblCustomerList cus)
        {
            try
            {
                tblLoginStatu addclient = new tblLoginStatu();
                addclient.iLockCount = 0;
                addclient.iId = 1;
                addclient.dLockedTime = DateTime.Now;
                addclient.vUserName = cus.vUserName;
                obj.tblLoginStatus.Add(addclient);
                obj.tblCustomerLists.Add(cus);
                obj.SaveChanges();
                return RedirectToAction("index");

            }
            catch (Exception)
            {

                return RedirectToAction("Error", "Shared");
            }
        }

        public ActionResult LoginCustomer()
        {
            
            return View();
        }
        [HttpPost]
        [ValidateInput(true)]
        public ActionResult LoginCustomer(Login credentails)
        {
            string username = credentails.vUserName;
            string Password = credentails.vPassword;

            tblLoginStatu ls = (from u in obj.tblLoginStatus where u.vUserName.Equals(username) && u.iId.Equals(1) select u).FirstOrDefault();

            if (ls !=null)
            {
                

            label1: if (ls.dLockedTime<= DateTime.Now)
                {
                    int count = ls.iLockCount;

                    if (ls.iLockCount < 3)
                    {

                        tblCustomerList user = (from u in obj.tblCustomerLists
                                                where u.vUserName.Equals(username) && u.vPassword.Equals(Password)
                                                select u).FirstOrDefault();

                        if (user != null)
                        {
                            Session["Id"] = user.iCustomerId;
                            Session["Name"] = user.vUserName;
                            Session["Key"] = user.vFirstName;

                            return RedirectToAction("Index", "Customer");
                        }
                        else
                        {
                            ls.iLockCount++;
                            int c = 4 - ls.iLockCount;
                            obj.SaveChanges();
                            ModelState.AddModelError("Error", "Wrong Password" + c + "more attempt left !!");
                            return View();
                        }
                    }
                    else
                    {
                       
                        ls.dLockedTime = DateTime.Now.AddMinutes(2);

                        obj.SaveChanges();
                        goto label1;
                    } 
                }
                else
                {  ls.iLockCount = 0;
                obj.SaveChanges();
                   MessageBox.Show("Maximum attempt reached try after 3 minutes!!");
                    return RedirectToAction("wait");
                }
                
            }
            else
            {
                ModelState.AddModelError("Error", "UserId and password do not match!!");
                return View();
            }
            return View();
        }
        public ActionResult wait()
        {
            return View();
        }
        public ActionResult LoginClerk()
        {
            return View();
        }
        [HttpPost]
        [ValidateInput(true)]
        public ActionResult LoginClerk(Login credentails)
        {
            string username = credentails.vUserName;
            string Password = credentails.vPassword;

            tblLoginStatu ls = (from u in obj.tblLoginStatus where u.vUserName.Equals(username) && u.iId.Equals(2) select u).FirstOrDefault();

            if (ls != null)
            {


            label1: if (ls.dLockedTime <= DateTime.Now)
                {
                    int count = ls.iLockCount;

                    if (ls.iLockCount < 3)
                    {

                        tblClerkList user = (from u in obj.tblClerkLists
                                                 where u.vUserName.Equals(username) && u.vPassword.Equals(Password)
                                                 select u).FirstOrDefault();

                        if (user != null)
                        {
                            Session["Id"] = user.iClerkId;
                            Session["Name"] = user.vUserName;
                            Session["Key"] = user.vUserName;

                            return RedirectToAction("Index", "Clerk");
                        }
                        else
                        {
                            ls.iLockCount++;
                            int c = 3 - ls.iLockCount;
                            obj.SaveChanges();
                            ModelState.AddModelError("Error", "Wrong Password" + c + "more attempt left !!");
                            return View();
                        }
                    }
                    else
                    {

                        ls.dLockedTime = DateTime.Now.AddMinutes(2);

                        obj.SaveChanges();
                        goto label1;
                    }
                }
                else
                {
                    ls.iLockCount = 0;
                    obj.SaveChanges();
                    MessageBox.Show("Maximum attempt reached try after 3 minutes!!");
                    return RedirectToAction("wait");
                }

            }
            else
            {
                ModelState.AddModelError("Error", "UserId and password do not match!!");
                return View();
            }
            return View();
        }
    }
}